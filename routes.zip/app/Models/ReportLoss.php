<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReportLoss extends Model
{
    use HasFactory;
    protected $table = "losses";
    protected $primaryKey = "loss_id";
    public $timestamps = true;
    public $incrementing = true;
    
    function getLoss($data = []){
        $data = [
            [
                "Name" => "$0.00",
                "Year1" => "$0.00",
                "Year2" => "$0.00",
                "Year3" => "$0.00",
                "Expenses" => "Exchange Gain or Losses"
            ],
            [
                "Name" => "$2,81,687.00",
                "Year1" => "$3,73,518.00",
                "Year2" => "$2,17,936.00",
                "Year3" => "$8,73,141.00",
                "Expenses" => "Stripe Fees"
            ],
            [
                "Name" => "$2,58,136.00",
                "Year1" => "$1,38,471.00",
                "Year2" => "$2,61,682.00",
                "Year3" => "$6,58,289.00",
                "Expenses" => "Total Expense"
            ],
            [
                "Name" => "$2,69,276.00",
                "Year1" => "$2,75,638.00",
                "Year2" => "$2,51,629.00",
                "Year3" => "$7,96,543.00",
                "Expenses" => "Net Income"
            ]
        ];
        return $data;
    }
}
