<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplies extends Model
{
    protected $table = "supplies";
    protected $primaryKey = "supplies_id";
    public $timestamps = true;
    public $incrementing = true;

    function getSupplies($data = []){
        $data = array_merge([
            "supplies_name"=>null,
            "supplies_desc"=>null,
            "supplies_unit"=>null,
            "supplies_stock"=>null,
        ], $data);
        $result = Supplies::where('status', '=', 1);
        if($data["supplies_name"]) $result->where('supplies_name','like','%'.$data["supplies_name"].'%');
        if($data["supplies_desc"]) $result->where('supplies_desc','like','%'.$data["supplies_desc"].'%');
        if($data["supplies_unit"]) $result->where('supplies_unit','like','%'.$data["supplies_unit"].'%');
        if($data["supplies_stock"]) $result->where('supplies_stock', '=', $data["supplies_stock"]);
        $result->orderBy('created_at', 'asc');
        
        $result = $result->get();
        foreach ($result as $key => $value) {
            // $value->unit = (new SuppliesUnit())->getSuppliesUnit(["supplies_id"=>$value->supplies_id]);
            // $temp = "";
            // foreach ($value->unit as $key => $unit) {
            //     $temp.=$unit->unit_name;
            //     if($key<count($value->unit)-1) $temp.=", ";
            // }
            // $value->unit_text = $temp;
            $value->supplies_unit = json_decode($value->supplies_unit);
            $value->sup_unit = Unit::whereIn('unit_id', $value->supplies_unit)->get();
            $value->sup_variant = (new SuppliesVariant())->getSuppliesVariant([
                "supplies_id" => $value->supplies_id
            ]);
        }
        return $result;
    }

    function insertSupplies($data)
    {
        $t = new Supplies();
        $t->supplies_name = $data["supplies_name"];
        $t->supplies_desc = $data["supplies_desc"];
        $t->supplies_unit = $data["supplies_unit"];
        $t->supplies_stock = 0;
        $t->save();
        return $t->supplies_id;
    }

    function updateSupplies($data)
    {
        $t = Supplies::find($data["supplies_id"]);
        $t->supplies_name = $data["supplies_name"];
        $t->supplies_desc = $data["supplies_desc"];
        $t->supplies_unit = $data["supplies_unit"];
        if(isset($data["supplies_stock"])) $t->supplies_stock = $data["supplies_stock"];
        $t->save();
        return $t->supplies_id;
    }

    function deleteSupplies($data)
    {
        $t = Supplies::find($data["supplies_id"]);
        $t->status = 0;
        $t->save();
    }
}
